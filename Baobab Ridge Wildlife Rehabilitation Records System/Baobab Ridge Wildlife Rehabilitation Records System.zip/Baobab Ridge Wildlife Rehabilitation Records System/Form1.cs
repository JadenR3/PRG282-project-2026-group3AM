﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Baobab_Ridge_Wildlife_Rehabilitation_Records_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnAddAnimal_Click(object sender, EventArgs e)
        {
            string AnimalName = txtName.Text.Trim();
            string Species = txtSpecies.Text.Trim();

            try
            {
                if (string.IsNullOrEmpty(AnimalName) || string.IsNullOrEmpty(Species))
                {
                    MessageBox.Show("Please enter both Animal Name and Species.", "Input Error");
                    return;
                }
                string filePath = "Animals.txt";
                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine($"{AnimalName},{Species}");
                }
                MessageBox.Show("Animal added successfully!", "Success");
                txtName.Clear();
                txtSpecies.Clear();

                int age = int.Parse(txtAge.Text);
                int score = int.Parse(txtRecovery.Text);

                if(age < 0 || score < 0)
                {
                    MessageBox.Show("Age and Recovery Score must be non-negative integers.", "Input Error");
                    return;
                }
                string status = " ";
                string careLocation = " ";

                if( score <= 18)
                {
                    status = "Critical";
                    careLocation = "Intensive Care Unit";
                }
                else if (score <= 39)
                {
                    status = "Serious";
                    careLocation = "High-Dependency Ward";
                }
                else if (score <= 59)
                {
                    status = "Stable";
                    careLocation = "Recovery Ward";
                }
                else if (score <= 79)
                {
                    status = "Recovering";
                    careLocation = "General Care Area";
                }
                else
                {
                    status = "Stable";
                    careLocation = "General Care Area";
                }

                lblStatus.Text = $"Status: {status}";
                lblCareLocation.Text = $"Care Location: {careLocation}";
                MessageBox.Show("All the information is valid");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while adding the animal: {ex.Message}");
            }
        }
    }
}